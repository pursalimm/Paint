﻿namespace Paint
{
    partial class FrmPaint
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmPaint));
            this.kFormManager1 = new Klik.Windows.Forms.v1.Common.KFormManager(this.components);
            this.elContainer1 = new Klik.Windows.Forms.v1.EntryLib.ELContainer();
            this.picErace = new System.Windows.Forms.PictureBox();
            this.picBrush = new System.Windows.Forms.PictureBox();
            this.picFill = new System.Windows.Forms.PictureBox();
            this.picArc = new System.Windows.Forms.PictureBox();
            this.elButton1 = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.picText = new System.Windows.Forms.PictureBox();
            this.picPencil = new System.Windows.Forms.PictureBox();
            this.picCircle = new System.Windows.Forms.PictureBox();
            this.picLine = new System.Windows.Forms.PictureBox();
            this.picRectangle = new System.Windows.Forms.PictureBox();
            this.txtPos = new System.Windows.Forms.TextBox();
            this.elPanel2 = new Klik.Windows.Forms.v1.EntryLib.ELPanel();
            this.w5 = new System.Windows.Forms.Panel();
            this.w1 = new System.Windows.Forms.Panel();
            this.w4 = new System.Windows.Forms.Panel();
            this.w2 = new System.Windows.Forms.Panel();
            this.w3 = new System.Windows.Forms.Panel();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.ClearPic = new System.Windows.Forms.ToolStripMenuItem();
            this.OpenPic = new System.Windows.Forms.ToolStripMenuItem();
            this.ExitApp = new System.Windows.Forms.ToolStripMenuItem();
            this.elPanel1 = new Klik.Windows.Forms.v1.EntryLib.ELPanel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.btnText = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.panel9 = new System.Windows.Forms.Panel();
            this.txtText = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.panel8 = new System.Windows.Forms.Panel();
            this.backgroundPanel = new System.Windows.Forms.Panel();
            this.Front_Color = new System.Windows.Forms.Panel();
            this.Back_Color = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.OpenImage = new System.Windows.Forms.OpenFileDialog();
            this.OpenColor = new System.Windows.Forms.ColorDialog();
            this.elContainer2 = new Klik.Windows.Forms.v1.EntryLib.ELContainer();
            this.PaintBox = new System.Windows.Forms.PictureBox();
            this.SelectFont = new System.Windows.Forms.FontDialog();
            this.SavePicture = new System.Windows.Forms.SaveFileDialog();
            this.SavePictureDive = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.kFormManager1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elContainer1)).BeginInit();
            this.elContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picErace)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBrush)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picFill)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picArc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elButton1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picText)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPencil)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCircle)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picLine)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRectangle)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elPanel2)).BeginInit();
            this.elPanel2.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.elPanel1)).BeginInit();
            this.elPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnText)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtText)).BeginInit();
            this.backgroundPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.elContainer2)).BeginInit();
            this.elContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PaintBox)).BeginInit();
            this.SuspendLayout();
            // 
            // kFormManager1
            // 
            this.kFormManager1.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.kFormManager1.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.kFormManager1.MainContainer = this;
            // 
            // elContainer1
            // 
            this.elContainer1.Controls.Add(this.picErace);
            this.elContainer1.Controls.Add(this.picBrush);
            this.elContainer1.Controls.Add(this.picFill);
            this.elContainer1.Controls.Add(this.picArc);
            this.elContainer1.Controls.Add(this.elButton1);
            this.elContainer1.Controls.Add(this.picText);
            this.elContainer1.Controls.Add(this.picPencil);
            this.elContainer1.Controls.Add(this.picCircle);
            this.elContainer1.Controls.Add(this.picLine);
            this.elContainer1.Controls.Add(this.picRectangle);
            this.elContainer1.Controls.Add(this.txtPos);
            this.elContainer1.Controls.Add(this.elPanel2);
            this.elContainer1.Location = new System.Drawing.Point(5, 31);
            this.elContainer1.Name = "elContainer1";
            this.elContainer1.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.elContainer1.Size = new System.Drawing.Size(100, 436);
            this.elContainer1.TabIndex = 0;
            // 
            // picErace
            // 
            this.picErace.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picErace.Image = ((System.Drawing.Image)(resources.GetObject("picErace.Image")));
            this.picErace.Location = new System.Drawing.Point(51, 139);
            this.picErace.Name = "picErace";
            this.picErace.Size = new System.Drawing.Size(25, 25);
            this.picErace.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picErace.TabIndex = 70;
            this.picErace.TabStop = false;
            this.picErace.Tag = "Erace";
            this.picErace.Click += new System.EventHandler(this.picRectF_Click);
            // 
            // picBrush
            // 
            this.picBrush.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picBrush.Image = ((System.Drawing.Image)(resources.GetObject("picBrush.Image")));
            this.picBrush.Location = new System.Drawing.Point(51, 108);
            this.picBrush.Name = "picBrush";
            this.picBrush.Size = new System.Drawing.Size(25, 25);
            this.picBrush.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picBrush.TabIndex = 68;
            this.picBrush.TabStop = false;
            this.picBrush.Tag = "ReadColor";
            this.picBrush.Click += new System.EventHandler(this.picRectF_Click);
            // 
            // picFill
            // 
            this.picFill.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picFill.Image = ((System.Drawing.Image)(resources.GetObject("picFill.Image")));
            this.picFill.Location = new System.Drawing.Point(51, 77);
            this.picFill.Name = "picFill";
            this.picFill.Size = new System.Drawing.Size(25, 25);
            this.picFill.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picFill.TabIndex = 64;
            this.picFill.TabStop = false;
            this.picFill.Tag = "Fill";
            this.picFill.Click += new System.EventHandler(this.picRectF_Click);
            // 
            // picArc
            // 
            this.picArc.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picArc.Image = ((System.Drawing.Image)(resources.GetObject("picArc.Image")));
            this.picArc.Location = new System.Drawing.Point(20, 46);
            this.picArc.Name = "picArc";
            this.picArc.Size = new System.Drawing.Size(25, 25);
            this.picArc.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picArc.TabIndex = 62;
            this.picArc.TabStop = false;
            this.picArc.Tag = "Arc";
            this.picArc.Click += new System.EventHandler(this.picRectF_Click);
            // 
            // elButton1
            // 
            this.elButton1.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elButton1.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elButton1.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.elButton1.Location = new System.Drawing.Point(12, 276);
            this.elButton1.Name = "elButton1";
            this.elButton1.Size = new System.Drawing.Size(73, 25);
            this.elButton1.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 9F);
            this.elButton1.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 9F);
            this.elButton1.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 9F);
            this.elButton1.StateStyles.PressedStyle.TextFont = new System.Drawing.Font("Tahoma", 9F);
            this.elButton1.TabIndex = 56;
            this.elButton1.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.elButton1.TextStyle.Text = "فونت متن";
            this.elButton1.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.elButton1.Click += new System.EventHandler(this.elButton1_Click);
            // 
            // picText
            // 
            this.picText.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picText.Image = ((System.Drawing.Image)(resources.GetObject("picText.Image")));
            this.picText.Location = new System.Drawing.Point(20, 77);
            this.picText.Name = "picText";
            this.picText.Size = new System.Drawing.Size(25, 25);
            this.picText.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picText.TabIndex = 54;
            this.picText.TabStop = false;
            this.picText.Tag = "Text";
            this.picText.Click += new System.EventHandler(this.picRectF_Click);
            // 
            // picPencil
            // 
            this.picPencil.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picPencil.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picPencil.Image = ((System.Drawing.Image)(resources.GetObject("picPencil.Image")));
            this.picPencil.Location = new System.Drawing.Point(20, 108);
            this.picPencil.Name = "picPencil";
            this.picPencil.Size = new System.Drawing.Size(25, 25);
            this.picPencil.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picPencil.TabIndex = 55;
            this.picPencil.TabStop = false;
            this.picPencil.Tag = "Pencil";
            this.picPencil.Click += new System.EventHandler(this.picRectF_Click);
            // 
            // picCircle
            // 
            this.picCircle.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picCircle.Image = ((System.Drawing.Image)(resources.GetObject("picCircle.Image")));
            this.picCircle.Location = new System.Drawing.Point(51, 15);
            this.picCircle.Name = "picCircle";
            this.picCircle.Size = new System.Drawing.Size(25, 25);
            this.picCircle.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picCircle.TabIndex = 58;
            this.picCircle.TabStop = false;
            this.picCircle.Tag = "Circle";
            this.picCircle.Click += new System.EventHandler(this.picRectF_Click);
            // 
            // picLine
            // 
            this.picLine.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picLine.Image = ((System.Drawing.Image)(resources.GetObject("picLine.Image")));
            this.picLine.Location = new System.Drawing.Point(51, 46);
            this.picLine.Name = "picLine";
            this.picLine.Size = new System.Drawing.Size(25, 25);
            this.picLine.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picLine.TabIndex = 56;
            this.picLine.TabStop = false;
            this.picLine.Tag = "Line";
            this.picLine.Click += new System.EventHandler(this.picRectF_Click);
            // 
            // picRectangle
            // 
            this.picRectangle.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picRectangle.Image = ((System.Drawing.Image)(resources.GetObject("picRectangle.Image")));
            this.picRectangle.Location = new System.Drawing.Point(20, 15);
            this.picRectangle.Name = "picRectangle";
            this.picRectangle.Size = new System.Drawing.Size(25, 25);
            this.picRectangle.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picRectangle.TabIndex = 59;
            this.picRectangle.TabStop = false;
            this.picRectangle.Tag = "Rectangle";
            this.picRectangle.Click += new System.EventHandler(this.picRectF_Click);
            // 
            // txtPos
            // 
            this.txtPos.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.txtPos.Enabled = false;
            this.txtPos.Location = new System.Drawing.Point(12, 408);
            this.txtPos.Name = "txtPos";
            this.txtPos.Size = new System.Drawing.Size(73, 22);
            this.txtPos.TabIndex = 2;
            // 
            // elPanel2
            // 
            this.elPanel2.BackgroundStyle.GradientAngle = 45F;
            this.elPanel2.Controls.Add(this.w5);
            this.elPanel2.Controls.Add(this.w1);
            this.elPanel2.Controls.Add(this.w4);
            this.elPanel2.Controls.Add(this.w2);
            this.elPanel2.Controls.Add(this.w3);
            this.elPanel2.Location = new System.Drawing.Point(12, 307);
            this.elPanel2.Name = "elPanel2";
            this.elPanel2.Size = new System.Drawing.Size(73, 95);
            this.elPanel2.TabIndex = 1;
            // 
            // w5
            // 
            this.w5.BackColor = System.Drawing.Color.Silver;
            this.w5.Location = new System.Drawing.Point(14, 68);
            this.w5.Name = "w5";
            this.w5.Size = new System.Drawing.Size(45, 15);
            this.w5.TabIndex = 6;
            this.w5.Tag = "5";
            this.w5.Click += new System.EventHandler(this.w1_Click);
            // 
            // w1
            // 
            this.w1.BackColor = System.Drawing.Color.Silver;
            this.w1.Location = new System.Drawing.Point(14, 12);
            this.w1.Name = "w1";
            this.w1.Size = new System.Drawing.Size(45, 5);
            this.w1.TabIndex = 2;
            this.w1.Tag = "1";
            this.w1.Click += new System.EventHandler(this.w1_Click);
            // 
            // w4
            // 
            this.w4.BackColor = System.Drawing.Color.Silver;
            this.w4.Location = new System.Drawing.Point(14, 51);
            this.w4.Name = "w4";
            this.w4.Size = new System.Drawing.Size(45, 11);
            this.w4.TabIndex = 5;
            this.w4.Tag = "4";
            this.w4.Click += new System.EventHandler(this.w1_Click);
            // 
            // w2
            // 
            this.w2.BackColor = System.Drawing.Color.Silver;
            this.w2.Location = new System.Drawing.Point(14, 23);
            this.w2.Name = "w2";
            this.w2.Size = new System.Drawing.Size(45, 7);
            this.w2.TabIndex = 3;
            this.w2.Tag = "2";
            this.w2.Click += new System.EventHandler(this.w1_Click);
            // 
            // w3
            // 
            this.w3.BackColor = System.Drawing.Color.Silver;
            this.w3.Location = new System.Drawing.Point(14, 36);
            this.w3.Name = "w3";
            this.w3.Size = new System.Drawing.Size(45, 9);
            this.w3.TabIndex = 4;
            this.w3.Tag = "3";
            this.w3.Click += new System.EventHandler(this.w1_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ClearPic,
            this.OpenPic,
            this.SavePictureDive,
            this.ExitApp});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(759, 24);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // ClearPic
            // 
            this.ClearPic.Name = "ClearPic";
            this.ClearPic.Size = new System.Drawing.Size(88, 20);
            this.ClearPic.Text = "پاک کردن تصویر";
            this.ClearPic.Click += new System.EventHandler(this.ClearPic_Click);
            // 
            // OpenPic
            // 
            this.OpenPic.Name = "OpenPic";
            this.OpenPic.Size = new System.Drawing.Size(79, 20);
            this.OpenPic.Text = "بازکردن تصویر";
            this.OpenPic.Click += new System.EventHandler(this.OpenPic_Click);
            // 
            // ExitApp
            // 
            this.ExitApp.Name = "ExitApp";
            this.ExitApp.Size = new System.Drawing.Size(43, 20);
            this.ExitApp.Text = "خروج";
            this.ExitApp.Click += new System.EventHandler(this.ExitApp_Click);
            // 
            // elPanel1
            // 
            this.elPanel1.BackgroundStyle.GradientAngle = 45F;
            this.elPanel1.Controls.Add(this.panel10);
            this.elPanel1.Controls.Add(this.btnText);
            this.elPanel1.Controls.Add(this.panel9);
            this.elPanel1.Controls.Add(this.txtText);
            this.elPanel1.Controls.Add(this.panel8);
            this.elPanel1.Controls.Add(this.backgroundPanel);
            this.elPanel1.Controls.Add(this.panel7);
            this.elPanel1.Controls.Add(this.panel2);
            this.elPanel1.Controls.Add(this.panel6);
            this.elPanel1.Controls.Add(this.panel1);
            this.elPanel1.Controls.Add(this.panel5);
            this.elPanel1.Controls.Add(this.panel3);
            this.elPanel1.Controls.Add(this.panel4);
            this.elPanel1.Location = new System.Drawing.Point(5, 473);
            this.elPanel1.Name = "elPanel1";
            this.elPanel1.Size = new System.Drawing.Size(747, 66);
            this.elPanel1.TabIndex = 3;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.Green;
            this.panel10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel10.Location = new System.Drawing.Point(193, 36);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(25, 25);
            this.panel10.TabIndex = 54;
            this.panel10.DoubleClick += new System.EventHandler(this.panel2_DoubleClick);
            this.panel10.Click += new System.EventHandler(this.panel2_Click);
            // 
            // btnText
            // 
            this.btnText.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnText.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnText.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnText.Location = new System.Drawing.Point(282, 38);
            this.btnText.Name = "btnText";
            this.btnText.Size = new System.Drawing.Size(75, 25);
            this.btnText.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 9F);
            this.btnText.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 9F);
            this.btnText.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 9F);
            this.btnText.StateStyles.PressedStyle.TextFont = new System.Drawing.Font("Tahoma", 9F);
            this.btnText.TabIndex = 3;
            this.btnText.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnText.TextStyle.Text = "تائید متن";
            this.btnText.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnText.Visible = false;
            this.btnText.Click += new System.EventHandler(this.btnText_Click);
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.Peru;
            this.panel9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel9.Location = new System.Drawing.Point(193, 6);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(25, 25);
            this.panel9.TabIndex = 52;
            this.panel9.DoubleClick += new System.EventHandler(this.panel2_DoubleClick);
            this.panel9.Click += new System.EventHandler(this.panel2_Click);
            // 
            // txtText
            // 
            this.txtText.CaptionStyle.CaptionSize = 140;
            this.txtText.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtText.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtText.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 9F);
            this.txtText.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 9F);
            this.txtText.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 9F);
            this.txtText.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.txtText.CaptionStyle.TextStyle.Text = "متن موردنظر را وارد نمائید";
            this.txtText.EditBoxStyle.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtText.EditBoxStyle.StateStyles.DisabledStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.txtText.EditBoxStyle.StateStyles.FocusStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.txtText.EditBoxStyle.StateStyles.HoverStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtText.Location = new System.Drawing.Point(363, 38);
            this.txtText.Name = "txtText";
            this.txtText.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtText.Size = new System.Drawing.Size(379, 25);
            this.txtText.TabIndex = 2;
            this.txtText.ValidationStyle.PasswordChar = '\0';
            this.txtText.Value = "Sample Text";
            this.txtText.Visible = false;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel8.Location = new System.Drawing.Point(162, 36);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(25, 25);
            this.panel8.TabIndex = 53;
            this.panel8.DoubleClick += new System.EventHandler(this.panel2_DoubleClick);
            this.panel8.Click += new System.EventHandler(this.panel2_Click);
            // 
            // backgroundPanel
            // 
            this.backgroundPanel.BackColor = System.Drawing.Color.White;
            this.backgroundPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.backgroundPanel.Controls.Add(this.Front_Color);
            this.backgroundPanel.Controls.Add(this.Back_Color);
            this.backgroundPanel.Location = new System.Drawing.Point(6, 6);
            this.backgroundPanel.Name = "backgroundPanel";
            this.backgroundPanel.Size = new System.Drawing.Size(55, 55);
            this.backgroundPanel.TabIndex = 1;
            this.backgroundPanel.Click += new System.EventHandler(this.backgroundPanel_Click);
            // 
            // Front_Color
            // 
            this.Front_Color.BackColor = System.Drawing.Color.Black;
            this.Front_Color.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Front_Color.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Front_Color.Location = new System.Drawing.Point(7, 21);
            this.Front_Color.Name = "Front_Color";
            this.Front_Color.Size = new System.Drawing.Size(25, 25);
            this.Front_Color.TabIndex = 43;
            this.Front_Color.DoubleClick += new System.EventHandler(this.panel2_DoubleClick);
            // 
            // Back_Color
            // 
            this.Back_Color.BackColor = System.Drawing.Color.Red;
            this.Back_Color.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Back_Color.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Back_Color.Location = new System.Drawing.Point(20, 6);
            this.Back_Color.Name = "Back_Color";
            this.Back_Color.Size = new System.Drawing.Size(25, 25);
            this.Back_Color.TabIndex = 44;
            this.Back_Color.DoubleClick += new System.EventHandler(this.panel2_DoubleClick);
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.Fuchsia;
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel7.Location = new System.Drawing.Point(162, 6);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(25, 25);
            this.panel7.TabIndex = 50;
            this.panel7.DoubleClick += new System.EventHandler(this.panel2_DoubleClick);
            this.panel7.Click += new System.EventHandler(this.panel2_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Red;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel2.Location = new System.Drawing.Point(69, 6);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(25, 25);
            this.panel2.TabIndex = 47;
            this.panel2.DoubleClick += new System.EventHandler(this.panel2_DoubleClick);
            this.panel2.Click += new System.EventHandler(this.panel2_Click);
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Blue;
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel6.Location = new System.Drawing.Point(131, 36);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(25, 25);
            this.panel6.TabIndex = 51;
            this.panel6.DoubleClick += new System.EventHandler(this.panel2_DoubleClick);
            this.panel6.Click += new System.EventHandler(this.panel2_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Yellow;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel1.Location = new System.Drawing.Point(69, 36);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(25, 25);
            this.panel1.TabIndex = 45;
            this.panel1.DoubleClick += new System.EventHandler(this.panel2_DoubleClick);
            this.panel1.Click += new System.EventHandler(this.panel2_Click);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Cyan;
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel5.Location = new System.Drawing.Point(131, 6);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(25, 25);
            this.panel5.TabIndex = 49;
            this.panel5.DoubleClick += new System.EventHandler(this.panel2_DoubleClick);
            this.panel5.Click += new System.EventHandler(this.panel2_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel3.Location = new System.Drawing.Point(100, 6);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(25, 25);
            this.panel3.TabIndex = 48;
            this.panel3.DoubleClick += new System.EventHandler(this.panel2_DoubleClick);
            this.panel3.Click += new System.EventHandler(this.panel2_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Lime;
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel4.Location = new System.Drawing.Point(100, 36);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(25, 25);
            this.panel4.TabIndex = 46;
            this.panel4.DoubleClick += new System.EventHandler(this.panel2_DoubleClick);
            this.panel4.Click += new System.EventHandler(this.panel2_Click);
            // 
            // elContainer2
            // 
            this.elContainer2.Controls.Add(this.PaintBox);
            this.elContainer2.Location = new System.Drawing.Point(112, 31);
            this.elContainer2.Name = "elContainer2";
            this.elContainer2.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.elContainer2.Size = new System.Drawing.Size(640, 436);
            this.elContainer2.TabIndex = 5;
            // 
            // PaintBox
            // 
            this.PaintBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.PaintBox.Cursor = System.Windows.Forms.Cursors.Cross;
            this.PaintBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PaintBox.Location = new System.Drawing.Point(4, 3);
            this.PaintBox.Name = "PaintBox";
            this.PaintBox.Size = new System.Drawing.Size(632, 430);
            this.PaintBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.PaintBox.TabIndex = 5;
            this.PaintBox.TabStop = false;
            this.PaintBox.MouseMove += new System.Windows.Forms.MouseEventHandler(this.PaintBox_MouseMove);
            this.PaintBox.MouseDown += new System.Windows.Forms.MouseEventHandler(this.PaintBox_MouseDown);
            this.PaintBox.MouseUp += new System.Windows.Forms.MouseEventHandler(this.PaintBox_MouseUp);
            // 
            // SavePicture
            // 
            this.SavePicture.Filter = "JPEG File (*.jpg)|*.jpg|Bitmap File (*.bmp)|*.bmp|PNG File(*.png)|*.png";
            // 
            // SavePictureDive
            // 
            this.SavePictureDive.Name = "SavePictureDive";
            this.SavePictureDive.Size = new System.Drawing.Size(73, 20);
            this.SavePictureDive.Text = "ذخیره تصویر";
            this.SavePictureDive.Click += new System.EventHandler(this.SavePictureDive_Click);
            // 
            // FrmPaint
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(759, 545);
            this.ControlBox = false;
            this.Controls.Add(this.elContainer2);
            this.Controls.Add(this.elPanel1);
            this.Controls.Add(this.elContainer1);
            this.Controls.Add(this.menuStrip1);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "FrmPaint";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "نقاشی";
            this.Load += new System.EventHandler(this.FrmPaint_Load);
            ((System.ComponentModel.ISupportInitialize)(this.kFormManager1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elContainer1)).EndInit();
            this.elContainer1.ResumeLayout(false);
            this.elContainer1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picErace)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBrush)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picFill)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picArc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elButton1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picText)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPencil)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCircle)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picLine)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRectangle)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elPanel2)).EndInit();
            this.elPanel2.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.elPanel1)).EndInit();
            this.elPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btnText)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtText)).EndInit();
            this.backgroundPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.elContainer2)).EndInit();
            this.elContainer2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.PaintBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Klik.Windows.Forms.v1.Common.KFormManager kFormManager1;
        private Klik.Windows.Forms.v1.EntryLib.ELContainer elContainer1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem ClearPic;
        private System.Windows.Forms.ToolStripMenuItem OpenPic;
        private System.Windows.Forms.ToolStripMenuItem ExitApp;
        private Klik.Windows.Forms.v1.EntryLib.ELPanel elPanel1;
        private System.Windows.Forms.Panel backgroundPanel;
        private Klik.Windows.Forms.v1.EntryLib.ELButton btnText;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtText;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel Front_Color;
        private System.Windows.Forms.Panel Back_Color;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel w5;
        private System.Windows.Forms.Panel w4;
        private System.Windows.Forms.Panel w3;
        private System.Windows.Forms.Panel w2;
        private System.Windows.Forms.Panel w1;
        private Klik.Windows.Forms.v1.EntryLib.ELPanel elPanel2;
        private System.Windows.Forms.TextBox txtPos;
        private System.Windows.Forms.OpenFileDialog OpenImage;
        private System.Windows.Forms.PictureBox picText;
        private System.Windows.Forms.PictureBox picPencil;
        private System.Windows.Forms.PictureBox picCircle;
        private System.Windows.Forms.PictureBox picLine;
        private System.Windows.Forms.PictureBox picRectangle;
        private System.Windows.Forms.ColorDialog OpenColor;
        private Klik.Windows.Forms.v1.EntryLib.ELContainer elContainer2;
        private System.Windows.Forms.PictureBox PaintBox;
        private System.Windows.Forms.FontDialog SelectFont;
        private Klik.Windows.Forms.v1.EntryLib.ELButton elButton1;
        private System.Windows.Forms.PictureBox picArc;
        private System.Windows.Forms.PictureBox picFill;
        private System.Windows.Forms.PictureBox picBrush;
        private System.Windows.Forms.PictureBox picErace;
        private System.Windows.Forms.ToolStripMenuItem SavePictureDive;
        private System.Windows.Forms.SaveFileDialog SavePicture;
    }
}

