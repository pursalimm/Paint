﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Paint
{
    public partial class FrmPaint : Form
    {
        Pen pen = null;
        string font;
        Graphics gf;
        Bitmap image;
        PictureBox pb = new PictureBox();
        public string Operate = "";

        List<Point> p = new List<Point>();
        private Point prev = new Point();
        private bool AllowDraw;
        private int X1=0, Y1=0, delimeter;
        private int FontSize;
        private string text;
        
        public FrmPaint()
        {
            InitializeComponent();
        }

        private void ExitApp_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void OpenPic_Click(object sender, EventArgs e)
        {
            if (OpenImage.ShowDialog() == DialogResult.OK)
                PaintBox.ImageLocation = OpenImage.FileName;
        }

        private void ClearPic_Click(object sender, EventArgs e)
        {
            gf.FillRectangle(Brushes.White, new Rectangle(0, 0, image.Width, image.Height));
        }

        private void backgroundPanel_Click(object sender, EventArgs e)
        {
            Color tmp = Back_Color.BackColor;
            Back_Color.BackColor = Front_Color.BackColor;
            Front_Color.BackColor = tmp;
            pen.Color = Front_Color.BackColor;
        }

        void border(PictureBox pb)
        {
            picErace.BorderStyle = picBrush.BorderStyle = picFill.BorderStyle = picCircle.BorderStyle = picPencil.BorderStyle = picLine.BorderStyle = picRectangle.BorderStyle = picText.BorderStyle = picArc.BorderStyle = BorderStyle.None;
            pb.BorderStyle = BorderStyle.FixedSingle;
        }

        private void panel2_Click(object sender, EventArgs e)
        {
            Panel panel = (Panel)sender;
            Front_Color.BackColor = panel.BackColor;
            pen.Color = Front_Color.BackColor;
        }

        private void w1_Click(object sender, EventArgs e)
        {
            Panel panel = (Panel)sender;
            w1.BorderStyle = w2.BorderStyle = w3.BorderStyle = w4.BorderStyle = w5.BorderStyle = BorderStyle.None;
            panel.BorderStyle = BorderStyle.FixedSingle;
            pen.Width = int.Parse(panel.Tag.ToString());
            delimeter = (int)pen.Width;
        }

        private void panel2_DoubleClick(object sender, EventArgs e)
        {
            Panel panel = (Panel)sender;
            if (OpenColor.ShowDialog() == DialogResult.OK)
                panel.BackColor = OpenColor.Color;
            pen.Color = Front_Color.BackColor;
        }

        private void btnText_Click(object sender, EventArgs e)
        {
            text = txtText.Text;
            btnText.Visible = false;
            txtText.Visible = false;
        }

        private void picRectF_Click(object sender, EventArgs e)
        {
            PictureBox pb = (PictureBox)sender;
            border(pb);
            Operate = pb.Tag.ToString();
            if (Operate == "Text")
            {
                txtText.Visible = true;
                btnText.Visible = true;
            }
            else if (Operate == "Arc")
                p.Clear();
        }

        private void elButton1_Click(object sender, EventArgs e)
        {
            if (SelectFont.ShowDialog() == DialogResult.OK)
                font = SelectFont.Font.Name;
        }

        private void FrmPaint_Load(object sender, EventArgs e)
        {
            image = new Bitmap(PaintBox.Width, PaintBox.Height);
            gf = PaintBox.CreateGraphics();
            gf = Graphics.FromImage(image);
            gf.FillRectangle(Brushes.White, new Rectangle(0, 0, image.Width, image.Height));
            PaintBox.Image = image;

            font = "Tahoma";
            w2.BorderStyle = BorderStyle.FixedSingle;
            AllowDraw = false;
            Operate = "Pencil";
            delimeter = 2;
            pen = new Pen(Color.Black);
        }

        private void PaintBox_MouseUp(object sender, MouseEventArgs e)
        {
            pen.Color = Front_Color.BackColor;
            pen.Width = delimeter;
            gf = Graphics.FromHwnd(PaintBox.Handle);
            SolidBrush sbh = new SolidBrush(Front_Color.BackColor);
            LinearGradientBrush bsh = new LinearGradientBrush(new Point(10, 20), new Point(40, 70), Color.Red, Color.YellowGreen);
            if (AllowDraw == true)
            {
                if (Operate == "Rectangle")
                {
                    //gf.Clear(Color.White);
                    gf.DrawRectangle(pen, X1, Y1, Math.Abs(X1 - e.X), Math.Abs(Y1 - e.Y));
                }
                if (Operate == "Circle")
                {
                    //gf.Clear(Color.White);
                    gf.DrawEllipse(pen, X1, Y1, Math.Abs(X1 - e.X), Math.Abs(Y1 - e.Y));
                }
                if (Operate == "Arc")
                {
                    if (p.Count > 1)
                    {
                        //gf.Clear(Color.White);
                        gf.DrawCurve(pen, p.ToArray());
                    }
                }
                if (Operate == "Line")
                {
                    //gf.Clear(Color.White);
                    gf.DrawLine(pen, new Point(X1, Y1), new Point(e.X, e.Y));
                }
                if (Operate == "Text")
                {
                    if (FontSize < 5)
                        FontSize = 5;
                    else
                        FontSize = Math.Abs(Y1 - e.Y);
                    try
                    {
                        //gf.Clear(Color.White);
                        gf.DrawString(text, new Font(font, FontSize), bsh, (float)X1, (float)Y1);
                    }
                    catch (ArgumentException Err)
                    {
                        FontSize = 5;
                    }
                }
                if (Operate == "Fill")
                {
                    GraphicsPath path = new GraphicsPath();
                    path.AddLines((new Point[] { new Point(150, 100), new Point(100, 150), new Point(100, 200), new Point(200, 100) }));
                    gf.FillPath(bsh, path);
                }
                if (Operate == "ReadColor")
                {
                    if (e.Button == MouseButtons.Left)
                        Front_Color.BackColor = image.GetPixel(e.X, e.Y);
                    pen.Color = Front_Color.BackColor;
                }
                prev = e.Location;
            }
            AllowDraw = false;
            X1 = Y1 = 0;
        }

        private void PaintBox_MouseDown(object sender, MouseEventArgs e)
        {
            AllowDraw = true;
            X1 = e.X;
            Y1 = e.Y;
            FontSize = 5;
            prev = e.Location;
            p.Add(e.Location);
        }

        private void PaintBox_MouseMove(object sender, MouseEventArgs e)
        {
            pen.Color = Front_Color.BackColor;
            pen.Width = delimeter;
            //gf = Graphics.FromHwnd(PaintBox.Handle);
            SolidBrush sbh = new SolidBrush(Front_Color.BackColor);
            LinearGradientBrush bsh = new LinearGradientBrush(new Point(10, 20), new Point(40, 70), Color.Red, Color.YellowGreen);
            if (AllowDraw == true)
            {
                if (Operate == "Pencil")
                {
                    gf.DrawLine(pen, e.Location, prev);
                }
                if (Operate == "Erace")
                {
                    Color tmp = pen.Color;
                    pen.Color = Color.White;
                    gf = PaintBox.CreateGraphics();
                    gf.DrawLine(pen, e.Location, prev);
                    pen.Color = tmp;
                }
                prev = e.Location;
            }
            txtPos.Text = e.X.ToString() + " , " + e.Y.ToString();
        }

        private void SavePictureDive_Click(object sender, EventArgs e)
        {
            if (SavePicture.ShowDialog() == DialogResult.OK)
                PaintBox.Image.Save(SavePicture.FileName);
        }
    }
}
